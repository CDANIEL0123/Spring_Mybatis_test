package polymorphism2;

public interface TV {
	public void powerOn() ;
	
	public void powerOff();
	
	public void soundUp();
	
	public void soundDown();
	
}
