package polymorphism3;

public class CollectionBean {
	private properties addressList;

	public properties getAddressList() {
		return addressList;
	}

	public void setAddressList(properties addressList) {
		this.addressList = addressList;
	}

}
