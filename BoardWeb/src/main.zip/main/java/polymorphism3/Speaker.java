package polymorphism3;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}