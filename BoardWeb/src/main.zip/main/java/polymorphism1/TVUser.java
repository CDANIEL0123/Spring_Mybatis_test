package polymorphism1;

public class TVUser {

	public static void main(String[] args) {
		LGTV tv = new LGTV();
		tv.turnOn();
		tv.turnOff();
		tv.soundUp();
		tv.soundDown();
	}

}
